import './App.css';
import { BrowserRouter, Link, Switch, Route, Router } from 'react-router-dom';
import Navigation from './components/Navigation/Navigation';
import Home from './components/Home/Home'
import Shop from './components/Shop/Shop'
import Blog from './components/Blog/Blog'
import ContactUs from './components/ContactUs/ContactUs'
import AboutUs from './components/AboutUs/AboutUs';
import BestSellers from './components/BestSellers/BestSellers';
import FeaturedProducts from './components/FeaturedProducts/FeaturedProducts';
import Footer from './components/Footer/Footer';
import axios from 'axios';
import { useEffect, useState } from 'react';
import { createContext } from 'react';
import Cart from './components/Cart/Cart';
import Favorite from './components/Favorite/Favorite';
import Checkout from './components/Checkout/Checkout';
import Product from './components/Product/Product';
import Login from './components/Login/Login';
export const Globalcontext = createContext()








function App() {
  const [quantity, setQuantity] = useState(1)
  const [constant, setConstant] = useState([])
  const [main, setMain] = useState(null)
  const [products, setProducts] = useState(null)
  const [productsId, setProductsId] = useState([])
  const [favorite,setFavorite]=useState([])
  const [Searchbar, setSearchbar] = useState(false)
  const [SearchbarAnimation, setSearchbarAnimation] = useState("open")
  const [cardcount, setCartcount] = useState(constant.filter(item => item.count > 0).reduce((total) =>  total = total + 1 , 0 ))






  const getinfo = async () => {
    let res = await axios.get("http://localhost:1337/products")
    setMain(res.data)
    setProducts(res.data)
    setConstant(res.data)

  }


  useEffect(() => {
    getinfo()
  }, [])

  // const basket = (id) => {

  //   products && products.map((num) => {
    
  //     if (num.id === id) {
  //       if (num.count) { num.count++
  //         console.log(num.count);      
  //        }
  //       else {

  //         num.count = 1
  //         setProductsId(productsId.concat(num))
  //         // console.log(productsId);

  //       }
  //     }
  //   })
  //   setCart(constant.filter(item => item.count > 0))
  //   setCartcount(constant.filter(item => item.count > 0).reduce((total) =>  total = total + 1 , 0 ))
  // }
  
  const basket = (id) => {
    products && products.map((number) => {
       if (number.id === id) {
         if (number.count && number.count<99) { number.count++ }
         else if (number.count==99){}
         else {
           number.count = 1
         }
       }
       setProductsId(constant.filter(item => item.count > 0))
       setCartcount(constant.filter(item => item.count > 0).reduce((total) => total = total + 1, 0))
       console.log(productsId);
     })
   }
   const basketminus = (id) => {
    products && products.map((number) => {
       if (number.id === id) {
         if (number.count>1) { number.count--}
       }
       setProductsId(constant.filter(item => item.count > 0))
       setCartcount(constant.filter(item => item.count > 0).reduce((total) => total = total + 1, 0))
     })
   }


  
  const favoritebutton = (id) => {
    main && main.map((number) => {    
      if (number.id === id) {
        if (number.fave) {
          number.fave = false
        }
        else {
          number.fave = true
        }
      }
      setFavorite(constant.filter(item => item.fave == true))
    })
  }
  function inputvalue(e) {
    console.log(e.target.value)
    var arr = []
    main && main.map((number) => {
      var tester = number.caption
      if (tester.toLowerCase().indexOf(e.target.value.toLowerCase()) > -1) {
        arr.push(number)
      }
      else {
        setProducts([])
      }
    })
    setProducts(arr)
    if (e.target.value === "") { setProducts(main) }
 
  }
  const SearchbarOpen = () => {
    setSearchbar(true)
    setSearchbarAnimation("open")
  }
  const SearchbarClose = () => {
    setSearchbarAnimation("close")
    setTimeout(function () { setSearchbar(false) }
      , 700
    )
  }
  const quantitychange = (e) => {
    if (e.target.value>99 ){}
    else {setQuantity(e.target.value) }
   }
   const basketproductchange = (id) => {
    main && main.map((number) => {
       if (number.id === id) {
         number.count=quantity
       }
       setProductsId(constant.filter(item => item.count > 0))
       setCartcount(constant.filter(item => item.count > 0).reduce((total) => total = total + 1, 0))
     })
     setQuantity(1)
   }
  

 


  return (
    <Globalcontext.Provider value={{products,main,basket,productsId,favorite,favoritebutton,cardcount,SearchbarOpen,SearchbarClose,Searchbar,SearchbarAnimation,inputvalue,basketminus,quantity,quantitychange,basketproductchange}}>
    <BrowserRouter>
      <div className='container' >
        <Navigation />

        <Switch>
        <Route path='/' exact>
            <Home />
            <BestSellers/>
            <FeaturedProducts/>
            <Blog/>
            <Footer/>
          </Route>
          <Route path='/home'>
            <Home />
            <BestSellers/>
            <FeaturedProducts/>
            <Blog/>
            <Footer/>
          </Route>
          <Route path='/shop' exact>
            <Shop />
            <Footer/>
          </Route>
          <Route path='/aboutus'>
            <AboutUs/>
            <Footer/>
          </Route>
          <Route path='/contactus'>
            <ContactUs />
            <Footer/>
          </Route>
          <Route path='/cart'>
            <Cart/>
          </Route>
          <Route path='/favorite'>
            <Favorite/>
          </Route>
          <Route path='/checkout'>
            <Checkout/>
          </Route>
          <Route path='/shop/:id'>
            <Product/>
            <Footer/>
          </Route>
          <Route path='/login'>
            <Login/>
          </Route>

        </Switch>

        

      </div>
    </BrowserRouter>
    </Globalcontext.Provider>
  );
}

export default App;
