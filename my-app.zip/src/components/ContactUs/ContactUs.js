
import styles from './ContactUs.module.css'
import React from 'react';






export default function ContactUs() {

  return (
    <section className={styles.sec_contact} >
      <div className={styles.frame} >
        <p>Our Location</p>

        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3037.766884004749!2d49.81889521489454!3d40.41401476372952!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40308795c7f959fd%3A0x67399476694109fa!2zMiBIw7xzZXluIFNleWlkemFkyZkga8O8w6fJmXNpLCBCYWvEsQ!5e0!3m2!1saz!2saz!4v1680103278804!5m2!1saz!2saz" ></iframe>



      </div>
      <div className={styles.info_con}  >
        <div className={styles.info} >
          <p>
            <i className="fa-solid fa-location-dot"></i>&nbsp;
            Unvan: Baki, Nesimi rayon, Huseyn Seydzade 5</p>
          <p>
            <i className="fa-solid fa-phone-volume"></i>&nbsp;
            Telefon: +994504788085</p>
          <p>
            <i className="fa-solid fa-envelope"></i>&nbsp;
            Email: peoni@gmail.com</p>
        </div>

        <div className={styles.comment} >

          <p>Bizimle elaqe</p>

          <input type="email" placeholder='Email' />
          <textarea placeholder='Mesajinizi qeyd edin' ></textarea>
          <div>
          <button>Gonder</button>
          </div>
        </div>
      </div>



    </section>
  )
}
