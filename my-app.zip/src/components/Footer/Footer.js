import React from 'react'
import styles from './Footer.module.css'
import Logo from '../Image/logobig.jpg'

export default function Footer() {
    return (
        <>

            <footer className={styles.footer}>
                <div className={styles.top} >
                    <div>
                        <img className={styles.logo} src={Logo} alt="logo" />
                        <p>Ən son yeniliklərdən xəbərdar olmaq üçün bizi sosial şəbəkələrdən izləyin.</p>
                        <p>Gözəlliyinizi bizə əmanət edin.</p>
                        <h4 className={styles.footer_text} >Sosial şəbəkələrimiz:</h4>
                        <div className={styles.social_media}>
                            <span><i className="fa-brands fa-facebook-f"></i></span>
                            <span><i className="fa-brands fa-twitter"></i></span>
                            <span><i className="fa-brands fa-youtube"></i></span>
                            <span><i className="fa-brands fa-google"></i></span>
                            <span><i className="fa-brands fa-instagram"></i></span>
                        </div>
                    </div>
                    <div className={styles.list_group} >
                        <div>
                            <h4>Açılış vaxtı</h4>
                            <ul>
                                <li>B.E - C. : 8AM - 10PM</li>
                                <li>Ş. : 9AM-8PM</li>
                                <li>B. : Bağlı</li>
                            </ul>
                        </div>
                        <div>
                            <h4>Məlumat</h4>
                            <ul className={styles.footer_info}>
                                <li>Çatdırılma</li>
                                <li>Haqqımızda</li>
                                <li>Əlaqə</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <hr />
                <div className={styles.bottom}> Müəllif hüququ &nbsp;<b>Coders Azerbaijan</b>	&nbsp; &copy; &nbsp;tərəfindən qorunur</div>
            </footer>

        </>

    )
}
