import React from 'react'
import { Globalcontext } from '../../App'
import styles from './Cart.module.css'
import { Link } from 'react-router-dom'

export default function Cart() {
    const mydata = React.useContext(Globalcontext)

    const total = (mydata.productsId.reduce((total, current) => total = total + current.price * current.count, 0
    ));
    return (
        <div className={styles.cart_total}>

            <table className={styles.cart_table}   >
                <thead>
                    <tr>
                        <th></th>
                        <th>Mehsulun adi</th>
                        <th>Qiymeti</th>
                        <th>Say</th>

                    </tr>
                </thead>
                <tbody>

                    {mydata.productsId && mydata.productsId.slice(0, 4).map((number, indexone) => {

                        return (



                            <tr key={indexone}>
                                <td>
                                    <div className={styles.image_box}>

                                        <div className={styles.image_hover}>
                                            <img className={styles.image} src={number.img1} alt="" />
                                            <img className={styles.image} src={number.img2} alt="" />
                                        </div>

                                    </div>

                                </td>
                                <td>
                                    {number.caption}
                                </td>
                                <td>
                                    {number.price} AZN
                                </td>
                                <td>
                                    <button className={styles.plus} onClick={() => { mydata.basketminus(number.id) }} style={{ cursor: "pointer" }}>-</button>

                                    <span>
                                        {number.count}
                                    </span>

                                    <button onClick={() => { mydata.basket(number.id) }} style={{ cursor: "pointer" }} >+</button>
                                </td>
                                <button className={styles.closed} >x</button>
                            </tr>




                        )







                    })}
                </tbody>

            </table>


            <div className={styles.total}>
                <b>Umumi mebleg</b>
                <div className={styles.sum}>
                    <div>
                        <span>Qiymetler cemi:</span>
                        <span>{total} AZN</span>
                    </div>
                    <div>
                        <span>Chatdirilma:</span>
                        <span>Pulsuz</span>
                    </div>
                    <div>
                        <span>
                            Umumi cem:
                        </span>
                        <span>{total} AZN</span>
                    </div>
                </div>
                <Link to="/checkout">
                    <button>
                        Checkout
                    </button>
                </Link>




            </div>

        </div>






    )






}
