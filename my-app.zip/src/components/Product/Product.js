import React from 'react'
import styles from './Product.module.css'
import { Globalcontext } from '../../App'
import { useState } from 'react'
import { useParams } from 'react-router-dom'


export default function Product() {
    const mydata = React.useContext(Globalcontext)
    const { id } = useParams()
    const [imagesource, setImagesource] = useState("none")
    function changesource(e) {
        setImagesource(e)
    }




    return (
        <section className={styles.big_container}>
            <section className={styles.container} >

                {mydata.main && mydata.main.filter(number => number.id === id).map((number, indexone) => {

                    return (

                        <div className={styles.img_container} key={indexone} >
                            <div className={styles.large_img} >
                                <i
                                    onClick={() => {
                                        if (imagesource == "none" || imagesource == number.img1) { changesource(number.img4) }
                                        else if (imagesource == number.img2) { changesource(number.img1) }
                                        else if (imagesource == number.img3) { changesource(number.img2) }
                                        else if (imagesource == number.img4) { changesource(number.img3) }
                                    }}




                                    style={{ left: "0" }} className="fa-solid fa-chevron-left"></i>
                                <img className={styles.image} src={imagesource.slice(1, number.imagesource)} alt="" style={{ display: imagesource.length > 4 ? "" : "none" }} />
                                <img className={styles.image} src={number.img1.slice(1, number.img1.length)} alt="" style={{ display: imagesource.length > 4 ? "none" : "" }} />
                                <i

                                    onClick={() => {
                                        if (imagesource == "none" || imagesource == number.img1) { changesource(number.img2) }
                                        else if (imagesource == number.img2) { changesource(number.img3) }
                                        else if (imagesource == number.img3) { changesource(number.img4) }
                                        else if (imagesource == number.img4) { changesource(number.img1) }
                                    }}




                                    style={{ right: "0" }} className="fa-solid fa-chevron-right"></i>
                            </div>


                            <div className={styles.lil_imgs}  >
                                <div>
                                    <img className={styles.image} src={number.img1.slice(1, number.img1.length)} onClick={() => { changesource(number.img1) }} alt="" /></div>
                                <div> <img className={styles.image} src={number.img2.slice(1, number.img2.length)} onClick={() => { changesource(number.img2) }} alt="" /></div>
                                <div> <img className={styles.image} src={number.img3.slice(1, number.img3.length)} onClick={() => { changesource(number.img3) }} alt="" /></div>
                                <div> <img className={styles.image} src={number.img4.slice(1, number.img4.length)} onClick={() => { changesource(number.img4) }} alt="" /></div>
                            </div>

                        </div >

                    )
                })}


                {mydata.main && mydata.main.filter(number => number.id === id).map((number, indexone) => {


                    return (
                        <div className={styles.text_container} key={indexone} >
                            <div className={styles.product_info} >
                                <p><strong>{number.caption}</strong></p>
                                <p>
                                    <i className=" yellow_star fa-solid fa-star"></i>
                                    <i class=" yellow_star fa-solid fa-star"></i>
                                    <i class=" yellow_star fa-solid fa-star"></i>
                                    <i class=" yellow_star  fa-solid fa-star"></i>
                                </p>
                                <p><i>{number.description}</i></p>
                                <p>
                                {number.text}
                                </p>
                                <p>Məhsul Kodu:  <span>{number.cod}</span> </p>
                                <p className={styles.price}><b>{number.price} AZN</b></p>

                                <hr />

                            </div>
                            <div className={styles.mix} >
                                <span>Say</span>
                                <input type="number" value={mydata.quantity} onInput={mydata.quantitychange} />
                                <button onClick={() => {
                  mydata.basketproductchange (number.id);}}>
                                    <i className="fa-solid fa-bag-shopping"></i>
                                    <span> SEBETE ELAVE ET</span>
                                </button>
                                <div>
                                    <i className="fa-regular fa-heart" onClick={() => { mydata.favoritebutton(number.id); }} style={{ color: number.fave ? "red" : "#B5B5B5" }}   ></i>
                                    <span>Favorilere elave et</span>
                                </div>
                            </div>
                        </div>


                    )


                })

                }

                {/* // <div className={styles.text_container} >
                //     <div className={styles.product_info} >
                //         <p><strong>Makyaj bazasi</strong></p>
                //         <p><i>Makyajin uzun muddet qalmasini temin edir. </i></p>
                //         <p>Məhsul Kodu:  <span>400</span> </p>
                //         <p className={styles.price}><b>50 AZN</b></p>
                //         <hr />

                //     </div>
                //     <div className={styles.mix} >
                //         <span>Say</span>
                //         <input type="number" name="" id="" />
                //         <button>
                //             <i className="fa-solid fa-bag-shopping"></i>
                //             <span> SEBETE ELAVE ET</span>
                //         </button>
                //         <div>
                //             <i className="fa-regular fa-heart"></i>
                //             <span>Favorilere elave et</span>
                //         </div>
                //     </div>
                // </div> */}


            </section>
            <section className={styles.reviews_container} >
                <hr />

                <table>
                    <caption>Reyler </caption>
                    <thead>
                        <tr>
                            <th>Aygul Abbaszade</th>
                            <th>15/03/2023</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Aliquam doloremque magnam, repellendus illum reiciendis perspiciatis maxime totam facilis libero corrupti at aspernatur quod fuga alias, nostrum hic aliquid repellat, harum facere quia! Illo eaque quia sapiente sequi, dolor, nobis, doloribus corrupti illum molestiae assumenda debitis in consequatur culpa nulla ullam!</td>
                        </tr>

                    </tbody>
                </table>



                <table>

                    <thead>
                        <tr>
                            <th>Nilay Musayeva</th>
                            <th>25/03/2023</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Aliquam doloremque magnam, repellendus illum reiciendis perspiciatis maxime totam facilis libero corrupti at aspernatur quod fuga alias, nostrum hic aliquid repellat, harum facere quia! Illo eaque quia sapiente sequi, dolor, nobis, doloribus corrupti illum molestiae assumenda debitis in consequatur culpa nulla ullam!</td>
                        </tr>

                    </tbody>
                </table>


                <div className={styles.write_text} >
                    <span>Reyinizi qeyd edin</span>
                    <p>*Ad</p>
                    <input type="text" name="" id="" />
                    <p>*Rey</p>
                    <textarea name="" id=""></textarea>
                    <div>
                        <button>Gonder</button>
                    </div>
                </div>





            </section>



        </section>
    )
}
