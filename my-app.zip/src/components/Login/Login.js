import React from 'react'
import styles from './Login.module.css'
import Logo from '../Image/loginLogo.jpg'


export default function Login() {
    return (
        <section className={styles.login} >


            <div className={styles.login_frame} >
                <div className={styles.paragraph} >
                    <img className={styles.logo} src={Logo} alt="logo" />
                    <button>x</button>
                </div>
                <div className={styles.input} >
                    <input placeholder='E-poct ve ya telefon nomresi' type="text" name="" id="" />
                    <input placeholder='Sifre' type="password" name="" id="" />
                </div>
                <button>Daxil ol</button>


            </div>

        </section>
    )
}
