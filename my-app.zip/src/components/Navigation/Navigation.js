import React,{useRef} from 'react'
import { BrowserRouter, Link, Switch, Route, Router } from 'react-router-dom';
import styles from './Navigation.module.css'
import { Globalcontext } from '../../App'
import Logo from '../Image/logobig.jpg'

export default function Navigation() {
    const mydata = React.useContext(Globalcontext)

    return (
        <>

            <nav className={styles.nav}>
                <h1  style={{display:"none"}} >Peony skin care</h1>
                <img className={styles.logo} src={Logo} alt="logo" />

                <div className={styles.link_group}>
                    <Link to="/home" >HOME</Link>
                    <Link to="/shop">SHOP</Link>
                    <Link to="/aboutus" >ABOUT US</Link>
                    <Link to="/contactus" >CONTACT US</Link>
                </div>
                <div className={styles.icon_group}>
                    <Link to="/shop"> <i  onClick={mydata.SearchbarOpen} className="fa-solid fa-magnifying-glass"></i></Link>
                    <Link to="/favorite" style={{textDecoration:"none"}}> <i className="fa-regular fa-heart"></i></Link>
                    <Link to="/cart"> <i className="fa-solid fa-bag-shopping"></i>({mydata.cardcount})</Link>
                    <Link to="/login"> <i className="fa-solid fa-user"></i></Link>
                    
                </div>
            </nav>


        </>

    )
}
