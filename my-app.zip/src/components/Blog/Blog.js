import React from 'react'
import styles from './Blog.module.css'
import BlogImg from '../Image/blogimg.jpg'

export default function Blog() {

  return (
    <>
      <section className={styles.blog_box}>
        <div className={styles.img_box}>
        <img src={BlogImg} alt="" />
        </div>
        <div className={styles.text} >
          <p>BLOQ</p>
          <span>Davamini Oxu <i className="fa-regular fa-circle-play"></i></span>
        </div>
      </section>
    </>
  )
}
