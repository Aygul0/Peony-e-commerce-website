import React from 'react'
import styles from './AboutUs.module.css'
import Image from '../Image/tempsnip.png'
import { Globalcontext } from '../../App'
import { BrowserRouter, Link, Switch, Route, Router } from 'react-router-dom';



export default function AboutUs() {
  const mydata = React.useContext(Globalcontext)
  return (

    <>
    <section className={styles.sec_about} >
      
      <div className={styles.info_about} >
        
        <div className={styles.info_left} >
          <p> <b>PEONY</b> 2023-cü ildə Aygül tərəfindən təsis edilib. Bu, bir sıra qabaqcıl makiyaj, üz və bədən prosedurlarını özündə cəmləşdirən Azərbaycan peşəkar kosmetika brendidir. Hər yaşda olan qadınların gözəllik tələblərini ödəmək üçün yaradılmış yüksək keyfiyyətli təhlükəsiz və effektiv məhsullar.</p>
          <b>ÖZ GÖZƏLİNİZİ TAPIN</b>
          <p>PEONY gözəllik vizyonunu belə yekunlaşdırır. Qeyri-adi geniş və müxtəlif çeşidli məhsullar vasitəsilə PEONY hər kəsə öz şəxsiyyətini ifadə etməyə imkan verir. Həyatınızın hər mərhələsində üslubunuza, dəri tonunuza, dəri tipinizə və xüsusi zövqünüzə uyğun bazarda unikal olan misilsiz müxtəlif rənglər, effektlər və hisslər. KIKO-nun kimliyi moda, incəsənət və dizaynın dünya paytaxtı kimi “Made in Azerbaijan” dəyərlərinə əsaslanır. Orijinal teksturaların, rənglərin və gözəlliyin təkamülünün ustaları olaraq, keyfiyyət və yaradıcılığın mükəmməl birləşməsi üçün zəmanətli performansa malik keyfiyyətli düsturlar təklif edirik.</p>
            <i>Əlçatan və Qarşısıalınmaz, Azərbaycandan Sevgi ilə.</i>
        </div>
        <div className={styles.info_right} >
          <img src={Image} alt="" />
        </div>
      </div>


    </section>





    <section className={styles.map_products}>
                <span className={styles.left_btn} >
                    <i className="fa-solid fa-chevron-left"></i>
                </span>

                {mydata.products && mydata.products.slice(0, 4).map((number, indexone) => {

                    return (
                        <div className={styles.product} key={indexone} >
                            <div className={styles.image_box}>
                            <Link to={`/shop/${number.id}`}>
                                <div className={styles.image_hover}>
                                    <img className={styles.image} src={number.img1} alt="" />
                                    <img className={styles.image} src={number.img2} alt="" />
                                </div>
                                </Link>
                                <div className={styles.cart_button}>
                                    <p onClick={() => { mydata.basket(number.id) }} style={{ cursor: "pointer" }}>SƏBƏTƏ AT</p>
                                    <div className={styles.icons}>
                                        <i className="fa-solid fa-magnifying-glass"></i>
                                        <i onClick={() => { mydata.favoritebutton(number.id); }} style={{ color: number.fave ? "red" : "#B5B5B5" }} className="fa-regular fa-heart"></i>
                                    </div>
                                </div>
                            </div>
                            <div className={styles.product_name}>
                                <p>
                                    <i className=" yellow_star fa-solid fa-star"></i>
                                    <i class=" yellow_star fa-solid fa-star"></i>
                                    <i class=" yellow_star fa-solid fa-star"></i>
                                    <i class=" yellow_star  fa-solid fa-star"></i>
                                </p>
                                <p>{number.caption}</p>
                                <p>{number.price} AZN </p>
                            </div>
                        </div>

                    )

                })}
                <span className={styles.right_btn} >
                    <i className="fa-solid fa-chevron-right"></i>
                </span>
            </section>





    </>
  )
}
