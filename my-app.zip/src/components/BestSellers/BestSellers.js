import React from 'react'
import styles from './BestSellers.module.css'
import { Globalcontext } from '../../App'
import { BrowserRouter, Link, Switch, Route, Router } from 'react-router-dom';



export default function BestSellers() {
    const mydata = React.useContext(Globalcontext)

    return (
        <>
            <section className={styles.box}>
                <div className={styles.title}>
                    <p>Ən çox satanlar</p>
                    <p>Yeni məhsullarımızın kolleksiyasını nəzərdən keçirin.</p>
                </div>
                <div className={styles.buttons}>
                    <button>Saç qulluğu</button>
                    <button>Dəri qulluğu</button>
                    <button>Kosmetika</button>
                </div>
            </section>

            <section className={styles.map_products}>
                <span className={styles.left_btn} >
                    <i className="fa-solid fa-chevron-left"></i>
                </span>

                {mydata.products && mydata.products.slice(0, 4).map((number, indexone) => {

                    return (
                        <div className={styles.product} key={indexone} >
                            <div className={styles.image_box}>
                            <Link to={`/shop/${number.id}`}>
                                <div className={styles.image_hover}>
                                    <img className={styles.image} src={number.img1} alt="" />
                                    <img className={styles.image} src={number.img2} alt="" />
                                </div>
                                </Link>
                                <div className={styles.cart_button}>
                                    <p onClick={() => { mydata.basket(number.id) }} style={{ cursor: "pointer" }}>SƏBƏTƏ AT</p>
                                    <div className={styles.icons}>
                                        <i className="fa-solid fa-magnifying-glass"></i>
                                        <i onClick={() => { mydata.favoritebutton(number.id); }} style={{ color: number.fave ? "red" : "#B5B5B5" }} className="fa-regular fa-heart"></i>
                                    </div>
                                </div>
                            </div>
                            <div className={styles.product_name}>
                                <p>
                                    <i className=" yellow_star fa-solid fa-star"></i>
                                    <i class=" yellow_star fa-solid fa-star"></i>
                                    <i class=" yellow_star fa-solid fa-star"></i>
                                    <i class=" yellow_star  fa-solid fa-star"></i>
                                </p>
                                <p>{number.caption}</p>
                                <p>{number.price} AZN </p>
                            </div>
                        </div>

                    )

                })}
                <span className={styles.right_btn} >
                    <i className="fa-solid fa-chevron-right"></i>
                </span>
            </section>
        </>
    )
}
